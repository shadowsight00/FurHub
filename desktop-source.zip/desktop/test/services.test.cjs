'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const {Services}=require('../src/services.cjs');
function harness(){const calls=[],vault={data:{},async set(k,v){if(v)this.data[k]=v;else delete this.data[k];}},store={data:{follows:[]}};const s=new Services(async()=>{},vault,store);s.request=async(source,path,params,options)=>{calls.push({source,path,params,options});return s.reply || {};};return {s,calls,vault,store};}
test('registered Inkbunny never changes rating preferences and following is read-only',async()=>{const {s,calls,vault}=harness();vault.data.inkbunny={id:'4',sid:'private',name:'name'};s.reply={submissions:[],pages_count:1};await s.search('inkbunny',{mode:'following'},1);assert.equal(calls.length,1);assert.equal(calls[0].path,'/api_search.php');assert.equal(calls[0].params.unread_submissions,'yes');assert(!calls.some(c=>c.path.includes('rating')||c.path.includes('unread.php')));});
test('Inkbunny cursor and raw page count survive fully blocked pages',async()=>{const {s,vault,calls}=harness();vault.data.inkbunny={id:'4',sid:'private'};s.reply={submissions:[{submission_id:1,hidden:'t'}],pages_count:3,rid:'cursor'};const r=await s.search('inkbunny',{mode:'favorites'},1,'existing');assert.deepEqual(r.items,[]);assert(r.more);assert.equal(r.rid,'cursor');assert.equal(calls[0].params.rid,'existing');});
test('e621 favorites parse actual returned status rather than force favoriting',async()=>{const {s,vault}=harness();vault.data.e621={id:'4',blacklist:''};s.reply={posts:[{id:3,is_favorited:false,file:{ext:'png'},tags:{}}]};assert.equal((await s.search('e621',{mode:'favorites'},1)).items[0].favorite,false);});
test('account login exposes no API key and never persists Inkbunny password',async()=>{const {s,vault}=harness();s.reply={sid:'session',user_id:'5',ratingsmask:'11111'};await s.connect('inkbunny','name','password');assert(!JSON.stringify(vault.data).includes('password'));assert(!JSON.stringify(s.status()).includes('session'));});
test('e621 verified login requires private blacklist response',async()=>{const {s,vault}=harness();s.reply={name:'name',id:1};await assert.rejects(()=>s.connect('e621','name','key'),/verify/);assert.deepEqual(vault.data,{});});
test('following feed splits e621 artist OR groups and merges identities',async()=>{const {s,store,calls}=harness();store.data.follows=['a','b','c','d','e'];s.reply={posts:[{id:3,file:{},tags:{}}]};const r=await s.search('e621',{mode:'following'},1);assert.equal(calls.length,2);assert.equal(calls[0].params.tags,'~a ~b ~c ~d');assert.equal(r.items.length,1);});

test('successful empty API responses do not turn unfavorite into an error',async()=>{const s=new Services(async()=>new Response(null,{status:204}),{data:{e621:{id:'1',name:'name',key:'key'}}},{data:{follows:[]}});assert.deepEqual(await s.favorite('5',false),{});});

test('desktop e621 search, favorites, following and details explicitly request legacy post format',async()=>{
  for(const mode of ['explore','favorites','following']) {
    const {s,vault,store,calls}=harness();vault.data.e621={id:'4'};store.data.follows=['artist'];
    s.reply={posts:[{id:3,file:{url:'https://static1.e621.net/a.jpg',ext:'jpg'},tags:{general:['landscape']}}]};
    const page=await s.search('e621',{mode,e621:'landscape'},1);
    assert.equal(calls[0].params.v1,true);assert.equal(page.items[0].files[0].type,'jpg');assert(page.items[0].tags.includes('landscape'));
  }
  const {s,calls}=harness();s.reply={post:{id:8,file:{},tags:{}}};await s.details('e621',8);assert.equal(calls[0].params.v1,true);
});
test('empty legacy e621 search is valid and unexpected formats remain actionable errors',async()=>{const {s}=harness();s.reply={posts:[]};assert.deepEqual((await s.search('e621',{mode:'explore'},1)).items,[]);s.reply={unexpected:true};await assert.rejects(()=>s.search('e621',{mode:'explore'},1),/Unexpected e621 response/);});
